#include <stdio.h>

int test_component2_version_major()
{
    return TEST_COMPONENT2_VER_MAJOR;
}

int test_component2_version_minor()
{
    return TEST_COMPONENT2_VER_MINOR;
}

int test_component2_version_patch()
{
    return TEST_COMPONENT2_VER_PATCH;
}
